/* Progress is earned by valid required inputs, never by optional fields. */
(()=>{
 const ids=['verify','terms','profile','photos','details','story','preview','complete'];
 let verified=false,finished=false;
 const touched=new Set(),storyTouched=new Set();
 const initialAnswers={...answers};
 const requirements=[...document.querySelectorAll('#terms .required')];
 for(const id of ids){const screen=document.getElementById(id);let bar=screen.querySelector('.ob-progress');if(!bar){bar=document.createElement('div');bar.className='ob-progress';bar.innerHTML='<i></i>';const top=screen.querySelector('.ob-top');top?top.after(bar):screen.prepend(bar);}bar.classList.add('signup-progress');bar.setAttribute('role','progressbar');bar.setAttribute('aria-label','가입 및 소개 완성');bar.setAttribute('aria-valuemin','0');bar.setAttribute('aria-valuemax','100');}
 function update(){
  const nick=document.getElementById('nickname').value.trim();
  const complete=[verified,...requirements.map(e=>touched.has('terms')&&e.checked),touched.has('nickname')&&nick.length>=2&&nick.length<=12,touched.has('gender')&&!!document.querySelector('[name="gender"]:checked'),touched.has('region')&&!!document.getElementById('region').value,touched.has('photo')&&!!photoUrls[0],storyTouched.has(0)&&validAnswer(0),completedQuestions().filter(id=>id!==0&&storyTouched.has(id)).length>=1,completedQuestions().filter(id=>id!==0&&storyTouched.has(id)).length>=2,finished];
  const n=complete.filter(Boolean).length,percent=Math.round(n/complete.length*100);
  document.querySelectorAll('.signup-progress').forEach(bar=>{bar.firstElementChild.style.width=percent+'%';bar.setAttribute('aria-valuenow',percent);bar.setAttribute('aria-valuetext','필수 항목 '+n+' / '+complete.length+' 완료');});
 }
 const oldShow=show;show=function(name){if(name==='terms'&&active==='verify'&&document.getElementById('demo-code').value==='123456')verified=true;if(name==='complete'&&active==='preview')finished=true;oldShow(name);update();};
 ['input','change'].forEach(type=>document.addEventListener(type,e=>{
 const el=e.target;if(['nickname','region'].includes(el.id))touched.add(el.id);if(el.name==='gender')touched.add('gender');if(el.closest('#terms'))touched.add('terms');if(el.matches('[data-photo]'))touched.add('photo');
 queueMicrotask(()=>{if(el.closest('#story'))Object.keys(answers).forEach(id=>{if(answers[id]!==initialAnswers[id])storyTouched.add(Number(id))});update()});
 }));
 document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;
 if(b.id==='profile-next')['nickname','gender','region'].forEach(x=>touched.add(x));
 if(b.closest('#photos .ob-bottom'))touched.add('photo');
 if(b.id==='story-next')completedQuestions().forEach(id=>storyTouched.add(id));
 queueMicrotask(update);
 },true);
 const photoObserver=new MutationObserver(update);photoObserver.observe(document.getElementById('photos'),{childList:true,subtree:true});
 update();
})();
