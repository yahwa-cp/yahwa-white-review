const assert=require('node:assert/strict');const R=require(process.argv[2]);const now=Date.now();const s={balance:90,points:10300,ledger:[],pointLedger:[],letters:[]};
assert.equal(R.reward(s,'like',now),5);assert.equal(R.reward(s,'like',now),5);assert.equal(R.reward(s,'like',now),0);
assert(R.send(s,{person:0,cost:40},now));assert(!R.send(s,{person:0,cost:40},now));R.expire(s,now+3*R.DAY);assert.equal(s.balance,100);R.expire(s,now+4*R.DAY);assert.equal(s.balance,100);
assert(R.convert(s,151,now));assert.equal(s.points,10150);assert(!R.convert(s,99999,now));
s.letters.push({id:'in',person:1,direction:'in',cost:80,at:now});assert(R.reply(s,'in','hello','demo',now));assert(!R.reply(s,'in','hello','demo',now));assert.equal(s.balance,101);
assert.equal(R.status({at:now,direction:'in',cost:40},now+3*R.DAY),'기간 만료');console.log('rules: passed');
// Refusing a received letter is private, permanent for introductions, and free of new notifications.
const refusal={balance:100,ledger:[],letters:[{id:'refuse',person:22,direction:'in',cost:80,at:now,readAt:now}],notifications:[]};
assert(R.decline(refusal,'refuse',now));assert(!R.decline(refusal,'refuse',now));assert(R.introExcluded(JSON.parse(JSON.stringify(refusal)),22));assert.equal(refusal.balance,100);assert.deepEqual(refusal.notifications,[]);assert.equal(R.status(refusal.letters[0],now),'거절');
const sender={...refusal.letters[0],direction:'out'};assert.equal(R.status(sender,now),'읽음');assert.equal(R.status(sender,now+3*R.DAY-1),'읽음');assert.equal(R.status(sender,now+3*R.DAY),'기간 만료');
const senderState={balance:0,ledger:[],letters:[sender]};R.expire(senderState,now+8*R.DAY);assert.equal(senderState.balance,0);assert(!R.send(refusal,{person:22,cost:40},now+8*R.DAY));
assert(R.letterPriority({cost:80,at:now-100},{cost:40,at:now})<0);assert(R.letterPriority({cost:80,at:now-100,readAt:now},{cost:40,at:now})>0);assert(R.letterPriority({cost:80,at:now},{cost:80,at:now-100})<0);
console.log('decline privacy, introduction exclusion, expiry and priority: passed');
const recent=[{id:'old',at:now-7*R.DAY,likes:Array(30)},{id:'nine',at:now,likes:Array(9)},{id:'popular',at:now-2*R.DAY,likes:Array(10)},{id:'tie',at:now-3*R.DAY,likes:Array(10)},{id:'removed',at:now,likes:Array(20),moderated:true}];
assert.deepEqual(R.popularPosts(recent,now).map(p=>p.id),['popular','tie']);assert.equal(recent[0].id,'old');
console.log('popular posts: exact 7-day expiry, 10-like threshold, moderation exclusion: passed');
const post={comments:[{id:'a'},{id:'b',parent:'a'},{id:'c',parent:'a'},{id:'d',parent:'b'}]};
assert.equal(R.commentThreads(post.comments)[0].replies.length,3);R.deleteComment(post,'b');assert(post.comments.some(c=>c.id==='d'));assert.equal(post.comments.find(c=>c.id==='d').parent,'a');R.deleteComment(post,'a');assert.equal(post.comments.length,2);assert.equal(R.commentThreads(post.comments).length,2);
assert.equal(R.profileAge('2007-11-06',Date.parse('2026-11-05T12:00:00Z')),null);assert.equal(R.profileAge('2007-11-05',Date.parse('2026-11-05T12:00:00Z')),19);assert.equal(R.profileAge('2000-02-30',now),null);
console.log('comment deletion retains others replies; birth validation: passed');

const lateRead={direction:'in',at:now,readAt:now+2*R.DAY};assert.equal(R.status(lateRead,now+3*R.DAY),'기간 만료');const joined={...lateRead,connectedAt:now+2*R.DAY};assert.equal(R.status(joined,now+9*R.DAY-1),'연결 완료');assert.equal(R.status(joined,now+9*R.DAY),'기간 만료');
