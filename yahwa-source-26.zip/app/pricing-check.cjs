const assert=require('node:assert/strict'),R=require('./features-rules.js');
const now=Date.now();
for(const [gender,fee] of [['남성',45],['여성',15]]){
 assert.equal(R.letterFee(gender),fee);
 for(const special of [false,true]){
  const s={balance:100,ledger:[],letters:[],core:{profile:{gender}}};
  const cost=(special?R.specialLetterFee(gender):fee);assert(R.send(s,{person:1,cost,kind:special?'special':'normal'},now));assert.equal(s.balance,100-cost);
  R.expire(s,now+3*R.DAY);assert.equal(s.balance,100);
  for(const incomingCost of [15,45,30,90,40,80,25,70]){
   const x={balance:100,ledger:[],letters:[{id:'a',direction:'in',at:now,cost:incomingCost}],core:{profile:{gender}}};
   assert(R.reply(x,'a','hello',{},now));assert.equal(x.balance,100-([30,90,80,25,70].includes(incomingCost)?0:fee));
  }
 }
 const daily={balance:0,ledger:[]};for(let d=0;d<3;d++){for(const kind of ['like','like','daily','post','comment'])R.reward(daily,kind,now+d*R.DAY);}assert.equal(daily.balance,45);
}
assert(R.letterPriority({cost:30,kind:'special',at:now-100},{cost:45,kind:'normal',at:now})<0);
assert(!R.specialLetter({cost:90,kind:'normal'}));
console.log('pricing: both genders, normal/special acceptance, legacy letters, exact refunds and 3-day rewards passed');

assert.equal(R.specialLetterFee('남성'),70);assert.equal(R.specialLetterFee('여성'),25);
