const assert=require('node:assert/strict'),R=require('./features-rules.js');
const ok={registered:true,approved:true,photo:'portrait.png',visible:true};
assert(R.exchangeAllowed(ok,ok));
for(const change of [{registered:false},{approved:false},{photo:null},{visible:false}]){
 assert(!R.exchangeAllowed({...ok,...change},ok));
 assert(!R.exchangeAllowed(ok,{...ok,...change}));
}
const t=Date.now(),s={balance:0,ledger:[]};
assert.equal(R.reward(s,'post',t),1);assert.equal(R.reward(s,'comment',t),1);
const restored=JSON.parse(JSON.stringify(s));
assert.equal(R.reward(restored,'post',t),0);assert.equal(R.reward(restored,'comment',t),0);
assert.equal(R.reward(restored,'post',t+R.DAY),1);assert.equal(R.reward(restored,'comment',t+R.DAY),1);
assert.equal(R.reward(restored,'post',t+R.DAY),0);
assert.equal(R.reward(restored,'like',t+R.DAY),5);
for(const [l,unread,label] of [
 [{direction:'in'},true,'안 읽음'],
 [{direction:'in',readAt:t},false,'읽음 · 답장 전'],
 [{direction:'in',readAt:t,connectedAt:t},false,'연락처 공개'],
 [{direction:'out',readAt:t,connectedAt:t},true,'연락처 공개'],
 [{direction:'out',readAt:t,connectedAt:t,seenReply:true},false,'연락처 공개']
]){assert.equal(R.letterUnread(l),unread);assert.equal(R.letterLabel(l),label);}
console.log('exchange eligibility, daily rewards across reload, letter badge/status consistency: passed');
