/* Browser-local review rules. No payment, account or messaging service calls. */
(function(root){
const DAY=86400000;
const letterFee=gender=>gender==='여성'?15:45;
const specialLetterFee=gender=>gender==='여성'?25:70;
const specialLetter=l=>l?.kind==='special'||(!l?.kind&&[80,90,30,70,25].includes(l?.cost));
const day=at=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul'}).format(new Date(at));
function ledger(s,delta,title,at){if(s.balance+delta<0)return false;s.balance+=delta;s.ledger.unshift({delta,title,at});return true;}
function reward(s,kind,at){const key=day(at);if(s.rewardDay!==key){s.rewardDay=key;s.rewards={};}const max=kind==='like'?2:1;if((s.rewards[kind]||0)>=max)return 0;const n=kind==='like'?5:kind==='daily'?3:1;s.rewards[kind]=(s.rewards[kind]||0)+1;ledger(s,n,({like:'호감 보내기',daily:'8명 확인',post:'오늘의 첫 글',comment:'오늘의 첫 댓글'})[kind],at);return n;}
function exchangeRemaining(r,at){const days=r.status==='done'?7:3;return Math.max(0,Math.ceil(((r.connectedAt||r.at)+days*DAY-at)/DAY));}
function expire(s,at){for(const r of s.requests||[]){if(['received','sent','done'].includes(r.status)&&exchangeRemaining(r,at)===0)r.status='expired';}for(const l of s.letters){if(l.direction==='out'&&!l.readAt&&!l.declined&&!l.refunded&&at-l.at>=3*DAY){l.refunded=true;ledger(s,l.cost,'미열람 편지 반환',at);}}}
function status(l,at){if(l.declined&&l.direction!=='out')return '거절';if(l.refunded)return '리프 반환';const readAt=l.readAt||(l.declined?(l.declinedAt||l.at):0);if(at-(l.connectedAt||l.at)>=(l.connectedAt?7:3)*DAY)return '기간 만료';if(l.connectedAt)return '연결 완료';return readAt?'읽음':'읽지 않음';}
function introExcluded(s,person){return (s.declinedPeople||[]).includes(person)||(s.letters||[]).some(l=>l.person===person&&l.declined);}
function decline(s,id,at){const l=s.letters.find(x=>x.id===id);if(!l||l.direction!=='in'||l.connectedAt||['거절','기간 만료','리프 반환'].includes(status(l,at)))return false;l.declined=true;l.declinedAt=at;l.readAt=l.readAt||at;s.declinedPeople=[...new Set([...(s.declinedPeople||[]),l.person])];return true;}
function letterPriority(a,b){return Number(specialLetter(b)&&!b.readAt)-Number(specialLetter(a)&&!a.readAt)||b.at-a.at;}
function convert(s,amount,at){if(!Number.isSafeInteger(amount)||amount<150||amount>s.points)return false;const leaves=Math.floor(amount/150);s.points-=leaves*150;s.pointLedger.unshift({delta:-leaves*150,title:'리프로 바꾸기',at});return ledger(s,leaves,'포인트 환전',at);}
function send(s,l,at){if(introExcluded(s,l.person))return false;if(s.letters.some(x=>x.person===l.person&&!['거절','리프 반환','기간 만료'].includes(status(x,at))))return false;if(!ledger(s,-l.cost,specialLetter(l)?'특별한 편지 보내기':'편지 보내기',at))return false;s.letters.unshift({...l,id:at+'-'+Math.random(),direction:'out',at});return true;}
function reply(s,id,body,contact,at,gender=s.core?.profile?.gender){const l=s.letters.find(x=>x.id===id);if(!l||l.direction!=='in'||l.connectedAt||['거절','기간 만료'].includes(status(l,at)))return false;const fee=specialLetter(l)?0:letterFee(gender);if(!ledger(s,-fee,'편지 답장',at))return false;l.reply=body;l.myContact=contact;l.connectedAt=at;return true;}
function introIssue(text){const compact=String(text||'').replace(/\s/g,'');if(compact.length<=30)return '내 이야기를 30자 넘게 들려주세요';if(/(.)\1{5,}/u.test(compact)||/^(.{1,12})\1{2,}$/u.test(compact))return '같은 글자나 표현을 반복하기보다 내 이야기를 들려주세요';const lines=String(text).split(/[.!?\n]+/).map(x=>x.trim()).filter(Boolean);if(lines.length>1&&new Set(lines).size<lines.length)return '같은 문장이 반복돼요. 다른 이야기를 조금 더 들려주세요';if((compact.match(/[가-힣a-zA-Z0-9]/g)||[]).length<20)return '알아볼 수 있는 문장으로 내 이야기를 들려주세요';return '';}
function popularPosts(posts,at){return posts.filter(p=>!p.moderated&&!p.deleted&&p.at<=at&&p.at>at-7*DAY&&p.likes.length>=10).slice().sort((a,b)=>b.likes.length-a.likes.length||b.at-a.at);}
function deleteComment(post,id){const item=post.comments.find(c=>c.id===id);if(!item)return false;post.comments=post.comments.filter(c=>c.id!==id);for(const c of post.comments)if(c.parent===id)c.parent=item.parent||null;return true;}
function commentThreads(comments){const ids=new Set(comments.map(c=>c.id));const rootOf=c=>{const seen=new Set([c.id]);let p=c;while(p.parent&&ids.has(p.parent)&&!seen.has(p.parent)){seen.add(p.parent);p=comments.find(x=>x.id===p.parent);}return p.id;};return comments.filter(c=>!c.parent||!ids.has(c.parent)).map(c=>({root:c,replies:comments.filter(x=>x.id!==c.id&&rootOf(x)===c.id)}));}
function profileAge(birth,at){if(!/^\d{4}-\d{2}-\d{2}$/.test(birth||''))return null;const d=new Date(birth+'T00:00:00Z');if(!Number.isFinite(+d)||d.toISOString().slice(0,10)!==birth)return null;const today=day(at),age=Number(today.slice(0,4))-Number(birth.slice(0,4))-(today.slice(5)<birth.slice(5)?1:0);return age>=19&&age<=100?age:null;}
function exchangeAllowed(a,b){return [a,b].every(x=>x&&x.registered===true&&x.approved===true&&!!x.photo&&x.visible===true);}
function letterUnread(l){return !l.declined&&!l.refunded&&(l.connectedAt?l.direction==='out'&&!l.seenReply:l.direction==='in'&&!l.readAt);}
function letterLabel(l){if(l.connectedAt)return '연락처 공개';return l.direction==='in'?(l.readAt?'읽음 · 답장 전':'안 읽음'):(l.readAt?'상대가 읽음':'상대가 아직 안 읽음');}
const api={letterFee,specialLetterFee,specialLetter,profileAge,deleteComment,commentThreads,exchangeAllowed,letterUnread,letterLabel,popularPosts,introExcluded,decline,letterPriority,introIssue,DAY,day,exchangeRemaining,ledger,reward,expire,status,convert,send,reply};root.YahwaRules=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window==='undefined'?globalThis:window);
