const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),cp=require('node:child_process');
const root=__dirname,app=path.join(root,'app'),html=fs.readFileSync(path.join(app,'index.html'),'utf8');
for(const file of ['features.js','features-rules.js','onboarding-refine.js','signup-progress.js'])new vm.Script(fs.readFileSync(path.join(app,file),'utf8'),{filename:file});
for(const [i,m] of [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)].entries())if(m[1].trim())new vm.Script(m[1],{filename:'index-inline-'+i});
for(const file of ['rules-check.cjs','exchange-check.cjs','letter-flow-check.cjs'])cp.execFileSync(process.execPath,[path.join(app,file),...(file==='rules-check.cjs'?['./features-rules.js']:[])],{stdio:'inherit'});
for(const m of html.matchAll(/(?:src|href)="\.\/([^"?#]+)(?:[^" ]*)"/g))if(!fs.existsSync(path.join(app,m[1])))throw Error('Missing asset: '+m[1]);
fs.cpSync(app,path.join(root,'dist'),{recursive:true});
console.log('Static build and asset checks passed.');
