const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),R=require('./app/features-rules.js');
const src=fs.readFileSync('app/features.js','utf8').replace(/\r\n/g,'\n');
const rewardSrc=src.slice(src.indexOf('const certRewards='),src.indexOf('function approvedCredential'));
let ctx={state:{balance:0,ledger:[]},R,now:()=>1234};vm.createContext(ctx);vm.runInContext(rewardSrc,ctx);
for(const [kind,amount] of [['학력',20],['직장',20],['소득',30],['전화번호',0]]){assert.equal(ctx.grantCredentialReward(kind),amount);assert.equal(ctx.grantCredentialReward(kind),0);}
assert.equal(ctx.state.balance,70);assert.equal(ctx.state.ledger.length,3);
ctx.state=JSON.parse(JSON.stringify(ctx.state));assert.equal(ctx.grantCredentialReward('학력'),0);assert.equal(ctx.state.balance,70);
const labelSrc=src.slice(src.indexOf('function letterListCopy(l){'),src.indexOf('\n\n',src.indexOf('function letterListCopy(l){')));
const labels={esc:x=>x,actionIcon:()=>'',demoMatches:[{name:'테스트'}]};vm.createContext(labels);vm.runInContext(labelSrc,labels);
for(const [l,expected] of [[{direction:'in'},'받은 편지'],[{direction:'in',readAt:1},'받은 편지'],[{direction:'out'},'보낸 편지 · 안 읽음'],[{direction:'out',readAt:1},'보낸 편지 · 읽음'],[{direction:'in',connectedAt:1},'서로 연결 · 연락처 공개']])assert.ok(labels.letterListCopy({...l,person:0,body:'편지 미리보기'}).includes(expected));
console.log('Certification rewards: one-time across reload; inbox: all five states passed.');


assert.ok(!labels.letterListCopy({direction:'in',person:0,body:'미리보기'}).includes('안 읽음'));
const paging={};vm.createContext(paging);vm.runInContext(src.slice(src.indexOf('function listWindow('),src.indexOf('function paginateList(')),paging);
for(const [total,wanted,shown,more,capped] of [[0,10,0,false,false],[9,10,9,false,false],[33,10,10,true,false],[33,20,20,true,false],[33,40,33,false,false],[50,50,50,false,false],[80,60,50,false,true]]){const r=paging.listWindow(total,wanted);assert.equal(r.shown,shown);assert.equal(r.more,more);assert.equal(r.capped,capped);}
console.log('List paging: 10-item increments, final page and 50-item cap passed.');
const missions={state:{rewardDay:R.day(1000),rewards:{like:2,daily:1,post:1,comment:1}},R,now:()=>1000};vm.createContext(missions);vm.runInContext(src.slice(src.indexOf('function dailyMissionCount('),src.indexOf('const inviteUrl=')),missions);assert.equal(missions.dailyMissionCount(),5);missions.state.rewards.like=1;assert.equal(missions.dailyMissionCount(),4);missions.now=()=>1000+R.DAY;assert.equal(missions.dailyMissionCount(),0);console.log('Daily mission count: five actions and day reset passed.');
